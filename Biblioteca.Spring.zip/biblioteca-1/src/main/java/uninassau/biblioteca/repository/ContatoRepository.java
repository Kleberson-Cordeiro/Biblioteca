package uninassau.biblioteca.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import uninassau.biblioteca.entity.Contato;


public interface ContatoRepository extends JpaRepository<Contato, Long> {

}
